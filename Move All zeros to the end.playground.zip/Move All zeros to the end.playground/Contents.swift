import Foundation

func endZeros(numbersArray: [Int]) -> [Int] {
    var resultArray: [Int] = []
    var count = 0
    for index in numbersArray.indices {
        if numbersArray[index] == 0 {
            count += 1
        } else {
            resultArray.append(numbersArray[index])
        }
    }
    let zerosArray = [Int](repeating: 0, count: count)
    return resultArray + zerosArray
    
}

print(endZeros(numbersArray: [6, 0, 8, 2, 3, 0, 4, 0, 1 ]))
